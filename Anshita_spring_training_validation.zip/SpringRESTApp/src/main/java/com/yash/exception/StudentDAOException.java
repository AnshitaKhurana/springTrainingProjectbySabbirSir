package com.yash.exception;

public class StudentDAOException extends Exception {
	
	private String message;
	public StudentDAOException(Throwable e, String message) {
		super(e);
		this.message=message;
	}
	
	public String getMessage(){
		return message;
	}

}
