package com.yash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.entity.Student;
import com.yash.exception.StudentDAOException;
import com.yash.integrate.ConnectionManager;

@Repository
public class JDBCStudentDAOImpl implements StudentDAO {
	@Autowired
	private ConnectionManager manager;

	@Override
	public List<Student> getAllStudents() throws StudentDAOException {
		Connection connection;
		List<Student> stuList=new ArrayList<Student>();
		try{
			 connection=manager.openConnection();
		
		Statement statement=connection.createStatement();
		ResultSet rs=statement.executeQuery("select * from student");
		
		while(rs.next()){
			Student stu=new Student();
			stu.setRollNo(rs.getInt("roll_no"));
			stu.setStudentName(rs.getString("student_name"));
			stu.setStudentAddress(rs.getString("student_address"));
			stuList.add(stu);
		}
	}
		catch(Exception e){
			throw new StudentDAOException(e, "Data Access Exception");
		}
		return stuList;
	}

	@Override
	public Student getStudentByRollNo(int rollNo) throws StudentDAOException {
		Student stu=new Student();
		try {
			Connection connection=manager.openConnection();
			PreparedStatement statement=connection.prepareStatement("select * from student where roll_no=?");
			statement.setInt(1, rollNo);
			ResultSet rs=statement.executeQuery();
			while(rs.next()){
				stu.setRollNo(rs.getInt("roll_no"));
				stu.setStudentName(rs.getString("student_name"));
				stu.setStudentAddress(rs.getString("student_address"));
			}
			
			
			
		} catch (Exception e) {
			
			throw new StudentDAOException(e, "Data Access Exception");
		}
		return stu;
	}

	@Override
	public boolean registerStudentData(Student student) throws StudentDAOException {
		int rows=0;
		try {
			Connection connection=manager.openConnection();
			PreparedStatement statement=connection.prepareStatement("insert into student values(?,?,?)");
			statement.setInt(1, student.getRollNo());
			statement.setString(2, student.getStudentName());
			statement.setString(3, student.getStudentAddress());
			rows=statement.executeUpdate();
		}
		catch(Exception e){
			throw new StudentDAOException(e, "Data Access Exception");
		}
		if(rows>0){
			return true;
		}
		else
			return false;
	}

}
