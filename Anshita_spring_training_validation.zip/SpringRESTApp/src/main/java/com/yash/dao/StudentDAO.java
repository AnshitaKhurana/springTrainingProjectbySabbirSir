package com.yash.dao;

import java.sql.SQLException;
import java.util.List;

import com.yash.entity.Student;
import com.yash.exception.StudentDAOException;

public interface StudentDAO {
	List<Student> getAllStudents() throws StudentDAOException;
	Student getStudentByRollNo(int rollNo) throws StudentDAOException;
	boolean registerStudentData(Student student) throws StudentDAOException;
}
