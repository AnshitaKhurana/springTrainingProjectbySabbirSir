package com.yash.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.custom.CustomHttpStatus;
import com.yash.model.StudentError;
import com.yash.model.StudentRegisteredResponse;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;
import com.yash.service.StudentService;

@RestController
@RequestMapping("student-app")
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	//@Autowired
	//private Validator validator;
	
	
	@GetMapping("students")
	public ResponseEntity<List<StudentResponse>> retrieveAllStudents(){
		List<StudentResponse> studentResponseList=studentService.studentRetrievalService();
		ResponseEntity<List<StudentResponse>> response=
				new ResponseEntity<>(studentResponseList, HttpStatus.OK);
		return response;
	}
	
	@GetMapping("students/{rollNo}")
	public ResponseEntity<StudentResponse> retrieveStudentByRollNo(@PathVariable int rollNo){
		StudentResponse studentResponse=studentService.studentRetrievalByRollNo(rollNo);
		ResponseEntity<StudentResponse> response=new ResponseEntity<StudentResponse>(studentResponse, HttpStatus.OK);
		return response;
	}
	
	@PostMapping("students")
	public ResponseEntity<StudentRegisteredResponse> persistStudent(@Valid @RequestBody StudentRequest studentRequest, Errors errors){
		//ValidationUtils.invokeValidator(validator, studentRequest, errors);
		if(errors.hasErrors()){
			List<StudentError> studentErrorList=new ArrayList<StudentError>();
			List<ObjectError> objectErrors=errors.getAllErrors();
			for(ObjectError e:objectErrors){
				StudentError stuError=new StudentError(); 
				stuError.setErrorCode(CustomHttpStatus.VALIDATION_FAILED);
				stuError.setErrorMessage(e.getDefaultMessage());
				studentErrorList.add(stuError);
			}
			StudentRegisteredResponse registeredResponse=new StudentRegisteredResponse();
			registeredResponse.setResponseMessage("validation error");
			registeredResponse.setStudentError(studentErrorList);
			return new ResponseEntity<StudentRegisteredResponse>(registeredResponse, HttpStatus.BAD_REQUEST);
			
		}
		else{
			boolean result=studentService.studentRegistrationService(studentRequest);
			if(result){
				StudentRegisteredResponse registeredResponse=new StudentRegisteredResponse();
				registeredResponse.setResponseMessage("Registered");
				return new ResponseEntity<StudentRegisteredResponse>(registeredResponse, HttpStatus.CREATED);
			}
			else{
				StudentRegisteredResponse registeredResponse=new StudentRegisteredResponse();
				registeredResponse.setResponseMessage("Not Registered");
				return new ResponseEntity<StudentRegisteredResponse>(registeredResponse, HttpStatus.CONFLICT);

			}
		}
		
	}
	
	
}
