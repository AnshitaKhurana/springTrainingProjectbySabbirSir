package com.yash.service;

import java.util.List;

import com.yash.exception.StudentDAOException;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;

public interface StudentService {
	 List<StudentResponse> studentRetrievalService();
	 public StudentResponse studentRetrievalByRollNo(int rollNo);
	 boolean studentRegistrationService(StudentRequest request);
}
