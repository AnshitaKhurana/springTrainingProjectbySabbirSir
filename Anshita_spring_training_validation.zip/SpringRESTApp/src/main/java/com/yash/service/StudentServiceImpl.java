package com.yash.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.dao.StudentDAO;
import com.yash.entity.Student;
import com.yash.exception.StudentDAOException;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;
@Service
public class StudentServiceImpl implements StudentService {
	@Autowired
	private StudentDAO studentDAO;
	
	@Override
	public List<StudentResponse> studentRetrievalService()  {
		
		List<StudentResponse> studentResponseList=new ArrayList<StudentResponse>();
		
		try {
			List<Student> studentList=studentDAO.getAllStudents();
			for(Student s:studentList){
				StudentResponse res=new StudentResponse();
				res.setRollNo(s.getRollNo());
				res.setStudentName(s.getStudentName());
				res.setStudentAddress(s.getStudentAddress());
				studentResponseList.add(res);
			}
		} catch (StudentDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return studentResponseList;
	}

	@Override
	public StudentResponse studentRetrievalByRollNo(int rollNo) {
		StudentResponse res=new StudentResponse();
		try {
			Student stu=studentDAO.getStudentByRollNo(rollNo);
			res.setRollNo(stu.getRollNo());
			res.setStudentAddress(stu.getStudentAddress());
			res.setStudentName(stu.getStudentName());
		} catch (StudentDAOException e) {
			
			e.printStackTrace();
		}
		return res;
	}

	@Override
	public boolean studentRegistrationService(StudentRequest request) {
		Student student=new Student();
		student.setRollNo(request.getRollNo());
		student.setStudentAddress(request.getStudentAddress());
		student.setStudentName(request.getStudentName());
		boolean result=false;
		try {
			result=studentDAO.registerStudentData(student);
		} catch (StudentDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

}
