package com.yash.validation;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.yash.model.StudentRequest;

@Component
public class StudentRequestValidator implements Validator {

	@Override
	public boolean supports(Class<?> arg0) {
		return StudentRequest.class.equals(arg0);
	}

	@Override
	public void validate(Object target, Errors errors) {
		StudentRequest studentRequest=(StudentRequest)target;
		String rollNo=String.valueOf(studentRequest.getRollNo());
		if(rollNo.length()<3){
			errors.rejectValue("rollNo", "Roll No must have atleast 4 digits");
		}
		if(studentRequest.getStudentName().length()<=0){
			errors.rejectValue("studentName", "Student Name can not be empty");
		}
		if(studentRequest.getStudentAddress().length()<=0){
			errors.rejectValue("studentAddress", "Student Address can not be empty");
		}
		
	}
	
}
