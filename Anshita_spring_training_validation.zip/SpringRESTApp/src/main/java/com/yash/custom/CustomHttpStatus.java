package com.yash.custom;

public enum CustomHttpStatus {
	VALIDATION_FAILED(400), DUPLICATE_RECORD_FOUND(908), STUDENT_DAO_EXCEPTION(907);
	private int val;
	private CustomHttpStatus(int val) {
		this.val=val;
	}
	public int getVal(){
		return val;
	}
}
