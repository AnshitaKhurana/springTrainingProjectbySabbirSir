package com.yash.client;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.yash.model.StudentResponse;

public class RetrieveStudentByRollNo {
	public static void main(String[] args) {
		RestTemplate template=new RestTemplate();
		String url="http://localhost:8082/student-app/students/{rollNo}";
		HttpHeaders headers=new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		HttpEntity<String> requestEntity=new HttpEntity<>(headers);
		ResponseEntity<StudentResponse> res=template.exchange(url, HttpMethod.GET, requestEntity, StudentResponse.class, 1);
		StudentResponse ressponse=res.getBody();
		System.out.println(ressponse);
		
	}
}
