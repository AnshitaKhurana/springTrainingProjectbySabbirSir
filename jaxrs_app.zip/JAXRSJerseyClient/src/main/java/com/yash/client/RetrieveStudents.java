package com.yash.client;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.filter.LoggingFilter;

import com.yash.model.StudentResponse;

public class RetrieveStudents {

	public static void main(String[] args) {
		Client client=ClientBuilder.newClient(new ClientConfig().register(LoggingFilter.class));
		WebTarget target=client.target("http://localhost:8082/JAXRSJerseyApp/rest/student-app").path("/students");
		List<StudentResponse> students=target.request(MediaType.APPLICATION_JSON).
				get(new GenericType<List<StudentResponse>>(){});
		
		for(StudentResponse res: students)
			System.out.println(res);
		
		
		
	}

}
