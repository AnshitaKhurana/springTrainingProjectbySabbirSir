package com.yash.client;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.filter.LoggingFilter;

import com.yash.model.StudentResponse;

public class RetrieveStudentByRollNo {

	public static void main(String[] args) {
		Client client=ClientBuilder.newClient(new ClientConfig().register(LoggingFilter.class));
		WebTarget target=client.target("http://localhost:8082/JAXRSJerseyApp/rest/student-app").path("/students").path(String.valueOf("1001"));
		StudentResponse response=target.request(MediaType.APPLICATION_JSON).
				get(new GenericType<StudentResponse>(){});
		System.out.println(response);
	}

}
