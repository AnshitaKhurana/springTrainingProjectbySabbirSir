package com.yash.message;

import java.io.IOException;
import java.io.InputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import javax.ws.rs.ProcessingException;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyReader;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import com.yash.model.StudentResponse;

public class StudentResponseMessageReader implements MessageBodyReader<StudentResponse> {


	public boolean isReadable(Class<?> arg0, Type arg1, Annotation[] arg2, MediaType arg3) {
		return arg0 ==StudentResponse.class;
	}

	public StudentResponse readFrom(Class<StudentResponse> arg0, Type arg1, Annotation[] arg2, MediaType arg3,
			MultivaluedMap<String, String> arg4, InputStream arg5) throws IOException, WebApplicationException {
		// TODO Auto-generated method stub
		try{
			JAXBContext jaxbContext=JAXBContext.newInstance(StudentResponse.class);
			StudentResponse studentResponse=(StudentResponse) jaxbContext.createUnmarshaller().unmarshal(arg5);
			return studentResponse;
			
		}
		catch(JAXBException e){
			throw new ProcessingException("Error deserializing a StudentResponse "+e);
		}
	}

}
