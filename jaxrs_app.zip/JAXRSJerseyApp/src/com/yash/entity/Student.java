package com.yash.entity;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Student {
	
		private int rollNo;
		private String StudentName;
		private String studentAddress;
		
		public Student(){
			
		}
		public int getRollNo() {
			return rollNo;
		}
		public void setRollNo(int rollNo) {
			this.rollNo = rollNo;
		}
		public String getStudentName() {
			return StudentName;
		}
		public void setStudentName(String studentName) {
			StudentName = studentName;
		}
		public String getStudentAddress() {
			return studentAddress;
		}
		public void setStudentAddress(String studentAddress) {
			this.studentAddress = studentAddress;
		}
		@Override
		public String toString() {
			return "Student [rollNo=" + rollNo + ", StudentName=" + StudentName + ", studentAddress=" + studentAddress
					+ "]";
		}
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((StudentName == null) ? 0 : StudentName.hashCode());
			result = prime * result + rollNo;
			result = prime * result + ((studentAddress == null) ? 0 : studentAddress.hashCode());
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Student other = (Student) obj;
			if (StudentName == null) {
				if (other.StudentName != null)
					return false;
			} else if (!StudentName.equals(other.StudentName))
				return false;
			if (rollNo != other.rollNo)
				return false;
			if (studentAddress == null) {
				if (other.studentAddress != null)
					return false;
			} else if (!studentAddress.equals(other.studentAddress))
				return false;
			return true;
		}
		
	

}
