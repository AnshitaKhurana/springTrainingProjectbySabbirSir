package com.yash.controller;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import javax.ws.rs.core.Response;
import com.yash.entity.Student;
import com.yash.factory.FactoryStudent;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;
import com.yash.model.StudentResponses;
import com.yash.service.StudentService;

@Path("/student-app")
public class StudentController {

	private StudentService studentService=null;
	public StudentController(){
		this.studentService=FactoryStudent.createStudentService();
	}
	
	@GET
	@Path("/students")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Student> getAllStudents_json(){
		List<Student> list=studentService.studentRetreivalService();
		return list;
	}
	
	@GET
	@Path(value="/students/{rollNo}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getInternById(@PathParam("rollNo") int rollNo){
		StudentResponse response=studentService.studentByRollNo(rollNo);
		return Response.status(Response.Status.OK).type(MediaType.APPLICATION_JSON).entity(response).build();
	}
	
	@POST
	@Path(value="/students")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response rejisterStudent(@FormParam("rollNo") int rollNo,
			@FormParam("studentName") String studentName,
			@FormParam("studentAddress") String studentAddress){
		
		StudentRequest request=new StudentRequest();
		request.setRollNo(rollNo);
		request.setStudentName(studentName);
		request.setStudentAddress(studentAddress);
		
		boolean result=studentService.rejisterStudent(request);
		if(result){
			return Response.status(Response.Status.OK).type(MediaType.APPLICATION_JSON).entity(request).build();
		}
		
		else{
			return Response.status(Response.Status.CONFLICT).type(MediaType.APPLICATION_JSON).build();
		}
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_XML)
	@Path(value="/students-xml")
	public Response registerStudent_xml(StudentRequest studentRequest){
		boolean result=studentService.rejisterStudent(studentRequest);
		if(result){
			StudentResponse studentResponse=new StudentResponse();
			studentResponse.setRollNo(studentRequest.getRollNo());
			studentResponse.setStudentAddress(studentRequest.getStudentAddress());
			studentResponse.setStudentName(studentRequest.getStudentName());
			return Response
					.status(Response.Status.OK)
					.type(MediaType.APPLICATION_XML)
					.entity(studentResponse)
					.build();
			
		}
		else
			return Response
					.status(Response.Status.CONFLICT)
					.type(MediaType.APPLICATION_XML)
					.build();
	}
	
	
	@POST
	@Path(value="/student_request")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response rejisterStudent(StudentRequest request){
		boolean result=studentService.rejisterStudent(request);
		if(result){
			return Response.status(Response.Status.OK).type(MediaType.APPLICATION_JSON).entity(request).build();
		}
		
		else{
			return Response.status(Response.Status.CONFLICT).type(MediaType.APPLICATION_JSON).build();
		}
	}
	
	@GET
	@Path("/students-xml")
	@Produces(MediaType.APPLICATION_XML)
	public StudentResponses getAllStudents_xml(){
		StudentResponses studentResponses=studentService.studentRetreivalService_xml();
		return studentResponses;
	}
	
	@PUT
	@Produces(MediaType.APPLICATION_XML)
	@Path(value="/students")
	public Response updateAddress(@QueryParam("rollNo") int rollNo, 
			@QueryParam("studentAddress") String address){
		boolean result=studentService.updateStudentAddress(rollNo, address);
		StudentResponse response=studentService.studentByRollNo(rollNo);
		if(result){
			return Response.status(Response.Status.OK).type(MediaType.APPLICATION_XML)
					.entity(response).build();
		}
		else{
			return Response.status(Response.Status.NOT_FOUND).type(MediaType.APPLICATION_XML)
					.build();
		}
	}
	
	//Matrix parameters
	
	@DELETE
	@Produces(MediaType.APPLICATION_XML)
	@Path(value="/students")
	public Response deleteStudent(@MatrixParam("rollNo") int rollNo){
		boolean result=studentService.deleteStudent(rollNo);
		if (result){
			return Response.status(Response.Status.OK).type(MediaType.APPLICATION_XML)
					.build();
		}
		else
			return Response.status(Response.Status.NOT_FOUND).type(MediaType.APPLICATION_XML)
			.build();
	}
}
