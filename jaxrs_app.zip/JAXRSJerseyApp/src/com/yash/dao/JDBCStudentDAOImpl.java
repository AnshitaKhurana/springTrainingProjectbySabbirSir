package com.yash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.yash.entity.Student;
import com.yash.integrate.ConnectionManager;

public class JDBCStudentDAOImpl implements StudentDAO {

	
	@Override
	public List<Student> getAllStudents() throws ClassNotFoundException, SQLException {
		Connection connection=ConnectionManager.openConnection();
		Statement stmt=connection.createStatement();
		ResultSet rs=stmt.executeQuery("select * from student");
		List<Student> list=new ArrayList<>();
		while(rs.next()){
			Student stu=new Student();
			stu.setRollNo(rs.getInt("roll_no"));
			stu.setStudentName(rs.getString("student_name"));
			stu.setStudentAddress(rs.getString("student_address"));
			list.add(stu);
		}
		ConnectionManager.closeConnection();
		return list;
	}

	@Override
	public Student getStudentByRollNo(int rollNo) throws ClassNotFoundException, SQLException {
		Connection connection=ConnectionManager.openConnection();
		PreparedStatement stmt=connection.prepareStatement("SELECT * FROM STUDENT WHERE ROLL_NO=?");
		stmt.setInt(1, rollNo);
		ResultSet rs=stmt.executeQuery();
		Student stu=new Student();
		while(rs.next()){
			stu.setRollNo(rs.getInt("roll_no"));
			stu.setStudentName(rs.getString("student_name"));
			stu.setStudentAddress(rs.getString("student_address"));
		}
		return stu;
	}

	@Override
	public boolean persistStudent(Student student) throws ClassNotFoundException, SQLException {
		Connection connection=ConnectionManager.openConnection();
		PreparedStatement stmt=connection.prepareStatement("insert into student values(?,?,?)");
		stmt.setInt(1, student.getRollNo());
		stmt.setString(2, student.getStudentName());
		stmt.setString(3, student.getStudentAddress());
		int rows=stmt.executeUpdate();
		if(rows>0)
			return true;
		else
			return false;
		
	}

	@Override
	public boolean updateStudentAddress(int rollNo, String address) throws ClassNotFoundException, SQLException {
		Connection connection=ConnectionManager.openConnection();
		PreparedStatement stmt=connection.prepareStatement("Update Student set student_address=? where roll_no=?");
		stmt.setString(1, address);
		stmt.setInt(2, rollNo);
		int rows=stmt.executeUpdate();
		if(rows>0)
			return true;
		else
		return false;
	}

	@Override
	public boolean deleteStudent(int rollNo) throws ClassNotFoundException, SQLException {
		Connection connection=ConnectionManager.openConnection();
		PreparedStatement stmt=connection.prepareStatement("delete from Student where roll_no=?");
		stmt.setInt(1, rollNo);
		int rows=stmt.executeUpdate();
		if(rows>0){
			return true;
		}
		else
			return false;
	}

}
