package com.yash.service;

import java.util.List;

import com.yash.entity.Student;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;
import com.yash.model.StudentResponses;

public interface StudentService {
	public List<Student> studentRetreivalService();
	public StudentResponses studentRetreivalService_xml();
	public StudentResponse studentByRollNo(int rollNo);
	public boolean rejisterStudent(StudentRequest studentRequest);
	public boolean updateStudentAddress(int rollNo, String Address);
	public boolean deleteStudent(int rollNo);
	
}
