package com.yash.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.yash.dao.StudentDAO;
import com.yash.entity.Student;
import com.yash.factory.FactoryStudent;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;
import com.yash.model.StudentResponses;

public class StudentServiceImpl implements StudentService {

	private StudentDAO studentDAO=null;
	 public StudentServiceImpl() {
		this.studentDAO=FactoryStudent.createStudentDAO();
	}
	

	@Override
	public List<Student> studentRetreivalService() {
		List<Student> studentList=new ArrayList<Student>();
		try {
			studentList=studentDAO.getAllStudents();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return studentList;
	}


	@Override
	public StudentResponse studentByRollNo(int rollNo) {
		StudentResponse studentResponse=new  StudentResponse();
		try {
			Student stu=studentDAO.getStudentByRollNo(rollNo);
			studentResponse.setRollNo(stu.getRollNo());
			studentResponse.setStudentName(stu.getStudentName());
			studentResponse.setStudentAddress(stu.getStudentAddress());
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return studentResponse;
	}


	@Override
	public boolean rejisterStudent(StudentRequest studentRequest) {
		Student stu=new Student();
		stu.setRollNo(studentRequest.getRollNo());
		stu.setStudentName(studentRequest.getStudentName());
		stu.setStudentAddress(studentRequest.getStudentAddress());
		boolean result=false;
		try {
			result=studentDAO.persistStudent(stu);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}


	@Override
	public StudentResponses studentRetreivalService_xml() {
		
		StudentResponses studentResponses=new StudentResponses();
		try {
			List<Student> studentList=studentDAO.getAllStudents();
			List<StudentResponse> studentResponsesList=new ArrayList<>();
			for(Student student: studentList){
				StudentResponse studentResponse=new StudentResponse();
				studentResponse.setRollNo(student.getRollNo());
				studentResponse.setStudentName(student.getStudentName());
				studentResponse.setStudentAddress(student.getStudentAddress());
				studentResponsesList.add(studentResponse);
			}
			studentResponses.setStudentResponse(studentResponsesList);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return studentResponses;
	}


	@Override
	public boolean updateStudentAddress(int rollNo, String address) {
		boolean result=false;
		try {
			result=studentDAO.updateStudentAddress(rollNo, address);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}


	@Override
	public boolean deleteStudent(int rollNo) {
		boolean result=false;
		try {
			result=studentDAO.deleteStudent(rollNo);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

}
