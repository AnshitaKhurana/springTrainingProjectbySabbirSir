package com.yash.integrate;

import java.util.ResourceBundle;

public class DataSource {
	
	private String url;
	private String driver;
	private String username;
	private String password;
	
	public DataSource(String baseName){
		ResourceBundle resource=ResourceBundle.getBundle(baseName);
		this.driver=resource.getString("driver");
		this.password=resource.getString("password");
		this.url=resource.getString("url");
		this.username=resource.getString("username");
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
