package com.yash.bean;

import org.springframework.stereotype.Component;

@Component
public class Bean7 {
	
	public Bean7() {
		
	}
	
	public void x(){
		System.out.println("bean7 method");
	}

}
