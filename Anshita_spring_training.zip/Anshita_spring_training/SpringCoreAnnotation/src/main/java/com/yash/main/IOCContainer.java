package com.yash.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.bean.Bean;
import com.yash.bean.Bean10;
import com.yash.bean.Bean9;
import com.yash.bean.DataSource;
import com.yash.bean.YashBean;
import com.yash.configuration.YashConfiguration;

public class IOCContainer {
	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
		Bean bean=(Bean) ctx.getBean("bean");
		bean.x();
		Bean9 bean9=(Bean9)ctx.getBean("bean9");
		System.out.println("Bean9 a= "+bean9.getA());
		System.out.println("Bean9 c= "+bean9.getC());
		System.out.println("Bean9 d= "+bean9.getD());
		DataSource dataSource=(DataSource) ctx.getBean("dataSource");
		System.out.println(dataSource);
		
		ApplicationContext ctx1=new AnnotationConfigApplicationContext(YashConfiguration.class);
		Bean10 bean10=ctx1.getBean(Bean10.class);
		YashBean yashBean=(YashBean) ctx1.getBean("yashBean");
	}
}
