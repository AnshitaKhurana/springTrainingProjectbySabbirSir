package com.yash.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Bean {
	
	@Autowired(required=true)
	@Qualifier(value="beanInterfaceImpl")
	private BeanInterface beanInterface;
	
	public Bean(){
		
	}
	public Bean(BeanInterface beanInterface ) {
		this.beanInterface=beanInterface;
		System.out.println("param constructor");
	}
	
	public void setBeanInterface(BeanInterface beanInterface){
		this.beanInterface=beanInterface;
		System.out.println("setter called");
	}
	
	public void x(){
		System.out.println("--x--");
		beanInterface.y();
	}
}
