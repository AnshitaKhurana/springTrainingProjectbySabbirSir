package com.yash.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BeanInterfaceImpl implements BeanInterface{

	public void y() {
		System.out.println("--y--BeanInterfaceImpl method");		
	}

}
