package com.yash.bean;

import org.springframework.stereotype.Component;

@Component
public class Bean10 {
	public Bean10() {
		System.out.println("bean 10 constructor");
	}
	public static int someValue(){
		return 100;
	}

}
