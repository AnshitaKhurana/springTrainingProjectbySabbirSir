package com.yash.bean;

import org.springframework.stereotype.Component;

@Component
public class BeanInterfaceImpl1 implements BeanInterface {

	public void y() {
		System.out.println("--y --BeanInterfaceImpl1 method---");
		
	}

}
