package com.yash.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Bean9 {
	@Value("#{T(com.yash.bean.Bean10).someValue()}")
	private int d;
	@Value("#{T(java.lang.Math).random()*100}")
	private int c;
	@Value(value="#{bean9.b}")			//expression language
	private int a;
	private int b;
	
	
	
	public int getD() {
		return d;
	}

	public void setD(int d) {
		this.d = d;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}
	
	

}
