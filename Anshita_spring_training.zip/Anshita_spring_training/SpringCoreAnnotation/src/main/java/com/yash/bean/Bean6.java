package com.yash.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
@Component

public class Bean6 {
	
	private Bean5 bean5;
	
	@Autowired
	public Bean6(Bean5 bean5) {
		this.bean5=bean5;
	}

}
