package com.yash.bean;

import org.springframework.stereotype.Component;


public interface BeanInterface {
	public void y();
}
