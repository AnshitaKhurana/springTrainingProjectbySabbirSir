package com.yash.configuration;

import org.springframework.context.annotation.Configuration;

@Configuration
public class EmailConfiguration {
	

}
