package com.yash.bean;

public class YashBean {

	public YashBean() {
		System.out.println("yashbean constructor");
	}

}
