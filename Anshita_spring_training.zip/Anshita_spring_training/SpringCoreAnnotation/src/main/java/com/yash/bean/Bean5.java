package com.yash.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class Bean5 {
	
	private Bean6 bean6;
	private Bean7 bean7;
	
	@Autowired
	public Bean5(@Lazy Bean6 bean6, Bean7 bean7) {
		this.bean6=bean6;
		this.bean7=bean7;
		System.out.println("param constructor bean5");
	}
	
	/*@Autowired(required=false)
	public Bean5(Bean7 bean7) {
		this.bean7=bean7;
		System.out.println("param constructor bean5");
	}*/
	
	public Bean5(String str){
		System.out.println("str constructor");
	}
	
}
