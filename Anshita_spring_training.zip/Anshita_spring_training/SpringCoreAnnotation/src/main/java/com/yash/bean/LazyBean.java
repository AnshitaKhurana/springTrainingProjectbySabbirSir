package com.yash.bean;

import org.springframework.context.annotation.Lazy;

@Lazy
// sop will never get printed unless we do getBean
public class LazyBean {

	public LazyBean() {
		System.out.println("--Lazybean constructor");
	}

}
