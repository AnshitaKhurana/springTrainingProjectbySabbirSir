package com.yash.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;

import com.yash.bean.YashBean;

@Configuration
@ComponentScan(basePackages="com.yash.*" )
@Import(EmailConfiguration.class)
@ImportResource("classpath:/applicationContext.xml")     //
@PropertySource("classpath:/db.properties")
@PropertySource("classpath:/UI.properties")
public class YashConfiguration {
	@Bean
	public YashBean yashBean(){
		return new YashBean();
	}

}
