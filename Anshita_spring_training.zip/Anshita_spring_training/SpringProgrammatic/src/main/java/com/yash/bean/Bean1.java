package com.yash.bean;

public class Bean1 {
	public Bean1() {
		System.out.println("Bean1 constructor");
	}
	
	public void x(){
		System.out.println("--x--");
	}
}
