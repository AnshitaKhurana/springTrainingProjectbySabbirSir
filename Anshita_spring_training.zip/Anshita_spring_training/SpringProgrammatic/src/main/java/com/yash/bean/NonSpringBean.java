package com.yash.bean;
//rejister this non spring bean as spring bean to IOC container
public class NonSpringBean {
	private int a;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}
	
}
