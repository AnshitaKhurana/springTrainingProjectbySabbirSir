package com.yash.bean;

import org.springframework.beans.factory.support.PropertiesBeanDefinitionReader;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class CreateBeanFromPropertiesFile {
	public static void main(String[] args) {
		GenericApplicationContext ctx=new GenericApplicationContext();
		PropertiesBeanDefinitionReader propReader=new PropertiesBeanDefinitionReader(ctx);
		propReader.loadBeanDefinitions(new ClassPathResource("bean.properties"));
		ctx.refresh();
		
		YashBean yashBean=(YashBean) ctx.getBean("yashBean");
		System.out.println("a: "+yashBean.getA());
	}
}
