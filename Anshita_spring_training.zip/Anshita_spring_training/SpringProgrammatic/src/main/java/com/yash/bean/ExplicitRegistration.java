package com.yash.bean;

import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.factory.config.ConstructorArgumentValues;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.support.GenericBeanDefinition;

public class ExplicitRegistration {
	public static void main(String[] args) {
		DefaultListableBeanFactory registry=new DefaultListableBeanFactory();
		GenericBeanDefinition beanDefn=new GenericBeanDefinition();
		beanDefn.setBeanClass(NonSpringBean.class);
		
		/*ConstructorArgumentValues constValues=new ConstructorArgumentValues();
		constValues.addIndexedArgumentValue(0, 1);*/
		MutablePropertyValues propertyValues=new MutablePropertyValues();
		propertyValues.add("a", 10);
		beanDefn.setPropertyValues(propertyValues);
		registry.registerBeanDefinition("nonSpring", beanDefn);
		
		NonSpringBean nonSpring =(NonSpringBean) registry.getBean("nonSpring");
		System.out.println(nonSpring.getA());
	}
	
}
