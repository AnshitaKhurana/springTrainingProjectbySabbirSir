package com.yash.bean;

import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class ExplicitlyLoadBeanDefinitions {
	public static void main(String[] args) {
		GenericApplicationContext gctx=new GenericApplicationContext();
		XmlBeanDefinitionReader xmlReader=new XmlBeanDefinitionReader(gctx);
		xmlReader.loadBeanDefinitions(new ClassPathResource("applicationContext.xml"));
		gctx.refresh();
		Bean1 bean1=(Bean1) gctx.getBean("bean1");
		bean1.x();
		
	}
}
