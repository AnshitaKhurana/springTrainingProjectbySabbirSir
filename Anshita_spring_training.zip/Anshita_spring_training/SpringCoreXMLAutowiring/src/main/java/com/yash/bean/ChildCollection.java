package com.yash.bean;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class ChildCollection {
	
	private List<String> cityNames;
	private Set<String> stateNames;
	private Map<String , String> countryNames;
	public List<String> getCityNames() {
		return cityNames;
	}
	public void setCityNames(List<String> cityNames) {
		this.cityNames = cityNames;
	}
	public Set<String> getStateNames() {
		return stateNames;
	}
	public void setStateNames(Set<String> stateNames) {
		this.stateNames = stateNames;
	}
	public Map<String, String> getCountryNames() {
		return countryNames;
	}
	public void setCountryNames(Map<String, String> countryNames) {
		this.countryNames = countryNames;
	}
	@Override
	public String toString() {
		return "ChildCollection [cityNames=" + cityNames + ", stateNames=" + stateNames + ", countryNames="
				+ countryNames + "]";
	}
	
}
