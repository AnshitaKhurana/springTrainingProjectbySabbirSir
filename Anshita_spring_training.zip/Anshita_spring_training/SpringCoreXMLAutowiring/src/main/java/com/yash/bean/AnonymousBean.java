package com.yash.bean;

import org.springframework.beans.factory.BeanNameAware;

public class AnonymousBean implements BeanNameAware{
	public AnonymousBean() {
		System.out.println("AnonymousBean constructor");
	}

	public void setBeanName(String arg0) {
		System.out.println("Name "+arg0);
		
	}
}
