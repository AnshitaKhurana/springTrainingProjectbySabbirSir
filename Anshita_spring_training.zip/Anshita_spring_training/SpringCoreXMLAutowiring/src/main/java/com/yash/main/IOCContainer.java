package com.yash.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.bean.AnonymousBean;
import com.yash.bean.Bean;
import com.yash.bean.Bean1;
import com.yash.bean.ChildCollection;
import com.yash.bean.OuterBean;
import com.yash.bean.ParentCollection;
import com.yash.bean.SubAbstractBean;

public class IOCContainer {
	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
		Bean bean=(Bean) ctx.getBean("bean");
		bean.y();
		Bean1 bean1=(Bean1)ctx.getBean("bean1");
		bean1.method1();
		SubAbstractBean childBean=(SubAbstractBean) ctx.getBean("subAbstractBean");
		System.out.println(childBean.getA());
		
		ParentCollection parent=(ParentCollection) ctx.getBean("parentCollection");
		System.out.println(parent);
		
		ChildCollection child=(ChildCollection) ctx.getBean("childCollection");
		System.out.println(child);
		OuterBean outerBean=(OuterBean)ctx.getBean("outerBean");
		AnonymousBean anonymousBean=outerBean.getAnonymousBean();
		
	}
}
