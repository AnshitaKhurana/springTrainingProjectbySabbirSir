package com.yash.bean;

public class Bean2 {
	private Bean1 bean1;
	private Bean3 bean3;
	public Bean2() {
		// TODO Auto-generated constructor stub
	}
	public Bean2(Bean1 bean1) {
		this.bean1=bean1;
	}
	


	public Bean3 getBean3() {
		return bean3;
	}

	public void setBean3(Bean3 bean3) {
		this.bean3 = bean3;
	}
	
	public void method2(){
		//bean3.method3();
	}
	
	
}
