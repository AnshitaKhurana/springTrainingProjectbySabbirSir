package com.yash.bean;

public class BeanA {
	
	{
		//initializer called before constructor
	}
	static{
		System.out.println("Bean A static Block");
	}
	public BeanA() {
		System.out.println("--BeanA constructor--");
	}
}
