package com.yash.bean;

public class Bean4 {
	
	/*private Bean1 bean1;
	
	
	
	public Bean1 getBean1() {
		return bean1;
	}



	public void setBean1(Bean1 bean1) {
		this.bean1 = bean1;
	}*/



	public void method4(){
		//System.out.println("Bean4 method");
	}
}
