package com.yash.bean;

public class Bean {
	
	private BeanInterface beanInterface;

	public BeanInterface getBeanInterface() {
		return beanInterface;
	}

	public void setBeanInterface(BeanInterface beanInterface) {
		this.beanInterface = beanInterface;
	}
	
	public void y(){
		beanInterface.x();
	}
	
}
