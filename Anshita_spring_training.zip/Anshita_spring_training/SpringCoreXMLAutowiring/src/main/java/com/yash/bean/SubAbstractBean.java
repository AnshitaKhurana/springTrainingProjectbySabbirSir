package com.yash.bean;

public class SubAbstractBean extends AbstractBean{
	public SubAbstractBean() {
		System.out.println("SubAbstract bean cons");
	}
}
