package com.yash.bean;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;

public class OuterBean implements BeanFactoryAware {
	
	 
	private BeanFactory beanFactory;
	class InnerBean{
		public InnerBean(){
			System.out.println("--Inner Bean--");
		}
	}
	public OuterBean() {
		System.out.println("OuterBean constructor");
	}
	private AnonymousBean anonymousBean;
	
	public AnonymousBean getAnonymousBean() {
		return anonymousBean;
	}
	public void setAnonymousBean(AnonymousBean anonymousBean) {
		this.anonymousBean = anonymousBean;
	}
	public void setBeanFactory(BeanFactory arg0) throws BeansException {
		this.beanFactory=beanFactory;
		
	} 
	
	
	
}
