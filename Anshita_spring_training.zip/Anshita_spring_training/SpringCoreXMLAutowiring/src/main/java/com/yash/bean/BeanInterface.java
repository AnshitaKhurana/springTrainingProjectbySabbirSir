package com.yash.bean;

public interface BeanInterface {
	public void x();
		
	
}
