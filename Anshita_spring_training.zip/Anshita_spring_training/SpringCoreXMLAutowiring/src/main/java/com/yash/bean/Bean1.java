package com.yash.bean;

public class Bean1 {
	private Bean2 bean2;

	public Bean1(Bean2 bean2) {
		this.bean2=bean2;
	}
	
	
	public void method1(){
		bean2.method2();
	}
	
}
