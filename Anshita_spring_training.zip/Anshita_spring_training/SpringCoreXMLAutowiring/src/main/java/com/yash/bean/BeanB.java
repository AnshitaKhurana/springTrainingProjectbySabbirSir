package com.yash.bean;

public class BeanB {
	
	public BeanB() {
		System.out.println("---BeanB constructor--");
	}
	public void x(){
		System.out.println("is using static block of A in some way");
	}
}
