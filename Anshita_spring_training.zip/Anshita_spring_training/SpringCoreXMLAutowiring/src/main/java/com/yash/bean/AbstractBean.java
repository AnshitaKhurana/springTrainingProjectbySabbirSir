package com.yash.bean;

public abstract class AbstractBean {
	public AbstractBean(){
		System.out.println("Abstract bean const");
	}
	private int a;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}
	
	
}
