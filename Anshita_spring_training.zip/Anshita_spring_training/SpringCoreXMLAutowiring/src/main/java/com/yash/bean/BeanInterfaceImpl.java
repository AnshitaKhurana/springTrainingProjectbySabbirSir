package com.yash.bean;
//@persistencecontext @entitymanager @query intyerfaces of jpa hibernate implements these
public class BeanInterfaceImpl implements BeanInterface{
	
	public void x(){
		System.out.println("--x--");
	}
}
